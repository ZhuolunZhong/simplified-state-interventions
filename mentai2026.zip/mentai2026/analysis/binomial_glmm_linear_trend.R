# Binomial GLMM Analysis for Success Rate Linear Trends
#
# This analysis addresses the bounded nature of success rate (0-1) by using
# a binomial GLMM with logit link. The success rate is the proportion of
# successes out of 100 simulated episodes per Q-table.
#
# Key advantages:
# - Logit link handles boundedness
# - Binomial variance function correctly captures compressed variance near 0 and 1
# - Random intercept by participant handles repeated measures
# - Round as numeric predictor directly estimates linear trend on log-odds scale

library(tidyverse)
library(lme4)
library(lmerTest)
library(emmeans)
library(car)

# Load data
roundwise_eval <- read_csv("../data/roundwise_evaluation_results.csv")

# Intervention types: 0=suggestion, 1=reset, 2=interrupt, 3=impede
intervention_labels <- c("suggestion", "reset", "interrupt", "impede")

add_conditions <- function(df) {
  df %>%
    mutate(
      intervention_idx = (experiment_id - 1) %% 4,
      intervention = factor(intervention_labels[intervention_idx + 1],
                           levels = c("suggestion", "impede", "interrupt", "reset")),
      vis_idx = ((experiment_id - 1) %/% 4) %% 2,
      visualization = factor(ifelse(vis_idx == 0, "vis", "non_vis"),
                            levels = c("vis", "non_vis")),
      participant_id = factor(experiment_id),
      round_num = as.numeric(round),  # 1, 2, 3 as numeric for linear trend
      round_factor = factor(round)    # For categorical comparisons
    )
}

data <- add_conditions(roundwise_eval)

cat("=" , rep("=", 69), "\n", sep = "")
cat("DATA OVERVIEW\n")
cat("=" , rep("=", 69), "\n", sep = "")
cat("\nTotal observations:", nrow(data), "\n")
cat("Unique participants:", n_distinct(data$experiment_id), "\n")

cat("\nSuccess rate distribution:\n")
print(summary(data$simulation_success_rate))
cat("\nProportion at boundaries:\n")
cat("  Exactly 0:", mean(data$simulation_success_rate == 0), "\n")
cat("  Exactly 1:", mean(data$simulation_success_rate == 1), "\n")
cat("  Near 0 (<0.1):", mean(data$simulation_success_rate < 0.1), "\n")
cat("  Near 1 (>0.9):", mean(data$simulation_success_rate > 0.9), "\n")

# Convert success rate to successes/trials for binomial GLMM
# Success rate is based on 100 simulated episodes
data <- data %>%
  mutate(
    n_trials = 100,
    n_successes = round(simulation_success_rate * 100)
  )

cat("\n" , rep("=", 69), "\n", sep = "")
cat("BINOMIAL GLMM WITH LINEAR TREND (ROUND AS NUMERIC)\n")
cat(rep("=", 69), "\n", sep = "")

# Model: intervention * round_num interaction tests whether linear slope
# differs between conditions. Main effect of round_num gives slope for
# reference condition (suggestion).
#
# Using cbind(successes, failures) syntax for binomial

model_linear <- glmer(
  cbind(n_successes, n_trials - n_successes) ~
    intervention * round_num + visualization + (1 | participant_id),
  data = data,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))
)

cat("\nModel Summary:\n")
print(summary(model_linear))

cat("\n" , rep("-", 69), "\n", sep = "")
cat("TYPE III WALD CHI-SQUARE TESTS\n")
cat(rep("-", 69), "\n", sep = "")
print(Anova(model_linear, type = "III"))

cat("\n" , rep("-", 69), "\n", sep = "")
cat("CONDITION-SPECIFIC LINEAR TRENDS (EMTRENDS)\n")
cat(rep("-", 69), "\n", sep = "")
cat("\nEstimated linear trends for each intervention type:\n")
cat("(Slopes are on log-odds scale per round)\n\n")

# emtrends gives the slope for each condition
trends <- emtrends(model_linear, ~ intervention, var = "round_num")
print(trends)

cat("\n\nPairwise comparisons of slopes:\n")
print(pairs(trends))

cat("\n" , rep("-", 69), "\n", sep = "")
cat("ESTIMATED MARGINAL MEANS BY INTERVENTION AND ROUND\n")
cat(rep("-", 69), "\n", sep = "")

# Get predicted probabilities at each round
emm_by_round <- emmeans(model_linear, ~ intervention | round_num,
                         at = list(round_num = 1:3),
                         type = "response")
print(emm_by_round)

cat("\n" , rep("=", 69), "\n", sep = "")
cat("MODEL WITH QUADRATIC TREND\n")
cat(rep("=", 69), "\n", sep = "")
cat("\nTesting whether adding round_num^2 improves fit...\n")
cat("(This can detect non-linear patterns like interrupt's gains only at round 2)\n\n")

# Center round_num for better interpretation of linear term
data$round_c <- data$round_num - 2  # Center at round 2

model_quadratic <- glmer(
  cbind(n_successes, n_trials - n_successes) ~
    intervention * (round_c + I(round_c^2)) + visualization + (1 | participant_id),
  data = data,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))
)

cat("Quadratic Model Summary:\n")
print(summary(model_quadratic))

cat("\n\nModel Comparison (Linear vs Quadratic):\n")
print(anova(model_linear, model_quadratic))

cat("\n" , rep("-", 69), "\n", sep = "")
cat("QUADRATIC TRENDS BY INTERVENTION\n")
cat(rep("-", 69), "\n", sep = "")

# emtrends for quadratic term
trends_quad <- emtrends(model_quadratic, ~ intervention, var = "round_c",
                         max.degree = 2)
print(trends_quad)

cat("\n" , rep("=", 69), "\n", sep = "")
cat("DESCRIPTIVE: SUCCESS RATE BY INTERVENTION AND ROUND\n")
cat(rep("=", 69), "\n", sep = "")

desc_stats <- data %>%
  group_by(intervention, round_num) %>%
  summarise(
    n = n(),
    mean_sr = mean(simulation_success_rate),
    sd_sr = sd(simulation_success_rate),
    median_sr = median(simulation_success_rate),
    .groups = "drop"
  )

print(desc_stats)

cat("\n\nChange from Round 1 to Round 3 by intervention:\n")
changes <- data %>%
  group_by(intervention, round_num) %>%
  summarise(mean_sr = mean(simulation_success_rate), .groups = "drop") %>%
  pivot_wider(names_from = round_num, values_from = mean_sr, names_prefix = "round") %>%
  mutate(
    change_1_to_2 = round2 - round1,
    change_2_to_3 = round3 - round2,
    change_1_to_3 = round3 - round1
  )
print(changes)

cat("\n" , rep("=", 69), "\n", sep = "")
cat("INTERPRETATION NOTES\n")
cat(rep("=", 69), "\n", sep = "")
cat("
1. BINOMIAL GLMM ADVANTAGES:
   - Correctly handles bounded outcome (0-1)
   - Accounts for compressed variance near boundaries
   - Coefficients are on log-odds scale

2. LINEAR TREND INTERPRETATION:
   - The round_num coefficient for each intervention represents
     the expected change in log-odds of success per round
   - Positive slopes indicate improvement over rounds
   - intervention:round_num interactions test whether slopes differ

3. QUADRATIC TREND:
   - If significant, suggests non-linear learning curves
   - Could explain patterns like interrupt showing gains at
     round 2 but not round 3

4. KEY COMPARISONS:
   - suggestion vs others: Does suggestion show steeper learning?
   - impede vs reset/interrupt: Does impede show different trajectory?
   - Quadratic terms: Are learning curves accelerating/decelerating?
")
