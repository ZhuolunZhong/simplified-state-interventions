# Plot Learning Curves by Intervention Type
# Creates a publication-quality figure showing success rate trajectories

library(tidyverse)
library(lme4)
library(emmeans)

# Load and prepare data
roundwise_eval <- read_csv("../data/roundwise_evaluation_results.csv")

intervention_labels <- c("suggestion", "reset", "interrupt", "impede")

data <- roundwise_eval %>%
  mutate(
    intervention_idx = (experiment_id - 1) %% 4,
    intervention = factor(intervention_labels[intervention_idx + 1],
                         levels = c("suggestion", "impede", "interrupt", "reset")),
    vis_idx = ((experiment_id - 1) %/% 4) %% 2,
    visualization = factor(ifelse(vis_idx == 0, "vis", "non_vis")),
    participant_id = factor(experiment_id),
    round_num = as.numeric(round),
    n_trials = 100,
    n_successes = round(simulation_success_rate * 100)
  )

# Fit the quadratic model to get predicted values
data$round_c <- data$round_num - 2

model_quad <- glmer(
  cbind(n_successes, n_trials - n_successes) ~
    intervention * (round_c + I(round_c^2)) + visualization + (1 | participant_id),
  data = data,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))
)

# Get model predictions - use finer grid for smooth curves
emm_grid <- emmeans(model_quad, ~ intervention | round_c,
                     at = list(round_c = seq(-1, 1, by = 0.1)),
                     type = "response")

# Convert to data frame for plotting
pred_df <- as.data.frame(emm_grid) %>%
  mutate(round = round_c + 2)  # Convert back to round 1, 2, 3

# Calculate raw means and SEs for observed data points
obs_summary <- data %>%
  group_by(intervention, round_num) %>%
  summarise(
    mean_sr = mean(simulation_success_rate),
    se_sr = sd(simulation_success_rate) / sqrt(n()),
    n = n(),
    .groups = "drop"
  ) %>%
  rename(round = round_num)

# Create color palette - colorblind friendly
colors <- c("suggestion" = "#0072B2",  # blue
            "impede" = "#009E73",       # green
            "interrupt" = "#D55E00",    # vermillion
            "reset" = "#CC79A7")        # pink

# Rename for cleaner labels
intervention_labels_plot <- c("suggestion" = "Suggestion",
                              "impede" = "Impede",
                              "interrupt" = "Interrupt",
                              "reset" = "Reset")

# =============================================================================
# OPTION 1: Faceted plot (clearest - no overlap)
# =============================================================================

p_facet <- ggplot() +
  # Model prediction line
  geom_line(data = pred_df,
            aes(x = round, y = prob),
            color = "gray30", linewidth = 1) +
  # Model CI ribbon
  geom_ribbon(data = pred_df,
              aes(x = round, ymin = asymp.LCL, ymax = asymp.UCL),
              fill = "gray50", alpha = 0.25) +
  # Observed data points with error bars
  geom_errorbar(data = obs_summary,
                aes(x = round, ymin = mean_sr - se_sr, ymax = mean_sr + se_sr),
                width = 0.15, linewidth = 0.7, color = "black") +
  geom_point(data = obs_summary,
             aes(x = round, y = mean_sr),
             size = 3, color = "black", fill = "white", shape = 21, stroke = 1.2) +
  # Facet by intervention
  facet_wrap(~ intervention, nrow = 1,
             labeller = labeller(intervention = intervention_labels_plot)) +
  # Styling
  scale_x_continuous(breaks = 1:3) +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.25)) +
  labs(
    x = "Round",
    y = "Success Rate"
  ) +
  theme_classic(base_size = 11) +
  theme(
    strip.text = element_text(face = "bold", size = 11),
    strip.background = element_rect(fill = "gray95", color = NA),
    axis.title = element_text(face = "bold"),
    axis.text = element_text(color = "black"),
    panel.grid.major.y = element_line(color = "gray90", linewidth = 0.3),
    panel.spacing = unit(0.8, "lines")
  )

ggsave("../figs/success_rate_learning_curves_faceted.pdf", p_facet,
       width = 7, height = 3, units = "in")
ggsave("../figs/success_rate_learning_curves_faceted.png", p_facet,
       width = 7, height = 3, units = "in", dpi = 300)

# =============================================================================
# OPTION 2: Combined plot with only lines and observed points (no ribbons)
# =============================================================================

p_lines <- ggplot() +
  # Model prediction lines (smooth curves)
  geom_line(data = pred_df,
            aes(x = round, y = prob, color = intervention),
            linewidth = 1.1) +
  # Observed data points with error bars (slightly dodged for visibility)
  geom_errorbar(data = obs_summary,
                aes(x = round, ymin = mean_sr - se_sr, ymax = mean_sr + se_sr,
                    color = intervention),
                width = 0.12, linewidth = 0.7,
                position = position_dodge(width = 0.15)) +
  geom_point(data = obs_summary,
             aes(x = round, y = mean_sr, color = intervention, shape = intervention),
             size = 3,
             position = position_dodge(width = 0.15)) +
  # Styling
  scale_color_manual(values = colors, labels = intervention_labels_plot) +
  scale_shape_manual(values = c(16, 17, 15, 18), labels = intervention_labels_plot) +
  scale_x_continuous(breaks = 1:3) +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  labs(
    x = "Round",
    y = "Success Rate",
    color = "Interpretation",
    shape = "Interpretation"
  ) +
  theme_classic(base_size = 12) +
  theme(
    legend.position = c(0.15, 0.82),
    legend.background = element_rect(fill = "white", color = "gray80"),
    legend.title = element_text(face = "bold", size = 10),
    legend.text = element_text(size = 9),
    axis.title = element_text(face = "bold"),
    axis.text = element_text(color = "black"),
    panel.grid.major.y = element_line(color = "gray90", linewidth = 0.3)
  )

ggsave("../figs/success_rate_learning_curves.pdf", p_lines,
       width = 5, height = 4, units = "in")
ggsave("../figs/success_rate_learning_curves.png", p_lines,
       width = 5, height = 4, units = "in", dpi = 300)

# =============================================================================
# OPTION 3: Combined with SE ribbons instead of model CIs
# =============================================================================

# Create ribbon data from observed SEs (interpolated)
ribbon_data <- obs_summary %>%
  group_by(intervention) %>%
  complete(round = seq(1, 3, by = 0.1)) %>%
  mutate(
    mean_sr = approx(round[!is.na(mean_sr)], mean_sr[!is.na(mean_sr)], round)$y,
    se_sr = approx(round[!is.na(se_sr)], se_sr[!is.na(se_sr)], round)$y
  ) %>%
  ungroup()

p_se_ribbon <- ggplot() +
  # SE ribbons (much narrower than model CIs)
  geom_ribbon(data = ribbon_data,
              aes(x = round, ymin = mean_sr - se_sr, ymax = mean_sr + se_sr,
                  fill = intervention),
              alpha = 0.2) +
  # Lines through observed means
  geom_line(data = ribbon_data,
            aes(x = round, y = mean_sr, color = intervention),
            linewidth = 1.1) +
  # Observed data points
  geom_point(data = obs_summary,
             aes(x = round, y = mean_sr, color = intervention, shape = intervention),
             size = 3.5) +
  # Styling
  scale_color_manual(values = colors, labels = intervention_labels_plot) +
  scale_fill_manual(values = colors, labels = intervention_labels_plot) +
  scale_shape_manual(values = c(16, 17, 15, 18), labels = intervention_labels_plot) +
  scale_x_continuous(breaks = 1:3) +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  labs(
    x = "Round",
    y = "Success Rate",
    color = "Interpretation",
    fill = "Interpretation",
    shape = "Interpretation"
  ) +
  theme_classic(base_size = 12) +
  theme(
    legend.position = c(0.15, 0.82),
    legend.background = element_rect(fill = "white", color = "gray80"),
    legend.title = element_text(face = "bold", size = 10),
    legend.text = element_text(size = 9),
    axis.title = element_text(face = "bold"),
    axis.text = element_text(color = "black"),
    panel.grid.major.y = element_line(color = "gray90", linewidth = 0.3)
  )

ggsave("../figs/success_rate_learning_curves_se.pdf", p_se_ribbon,
       width = 5, height = 4, units = "in")
ggsave("../figs/success_rate_learning_curves_se.png", p_se_ribbon,
       width = 5, height = 4, units = "in", dpi = 300)

cat("Plots saved:\n")
cat("  success_rate_learning_curves.pdf/png - Lines + points (no ribbons)\n")
cat("  success_rate_learning_curves_faceted.pdf/png - Faceted by condition\n")
cat("  success_rate_learning_curves_se.pdf/png - SE ribbons (narrower)\n")

# Print summary
cat("\nObserved means by condition and round:\n")
print(obs_summary %>% pivot_wider(names_from = round, values_from = c(mean_sr, se_sr, n)))
