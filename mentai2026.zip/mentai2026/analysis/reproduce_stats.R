# Reproduce the statistics reported in the CogSci paper

library(tidyverse)
library(lmerTest)
library(emmeans)
library(effectsize)

# Load data
roundwise_eval <- read_csv("../data/roundwise_evaluation_results.csv")

# Intervention types: 0=suggestion, 1=reset, 2=interrupt, 3=impede
# Visualization: 0=vis, 1=non_vis
intervention_labels <- c("suggestion", "reset", "interrupt", "impede")

add_conditions <- function(df) {
  df %>%
    mutate(
      intervention_idx = (experiment_id - 1) %% 4,
      intervention = factor(intervention_labels[intervention_idx + 1],
                           levels = c("suggestion", "impede", "interrupt", "reset")),
      vis_idx = ((experiment_id - 1) %/% 4) %% 2,
      visualization = factor(ifelse(vis_idx == 0, "vis", "non_vis"),
                            levels = c("vis", "non_vis")),
      participant_id = factor(experiment_id),
      round = factor(round)
    )
}

roundwise_data <- add_conditions(roundwise_eval)

cat("======================================================================\n")
cat("DATA OVERVIEW\n")
cat("======================================================================\n")
cat("\nTotal observations:", nrow(roundwise_data), "\n")
cat("Unique participants:", n_distinct(roundwise_data$experiment_id), "\n")

cat("\nParticipant counts by condition:\n")
print(roundwise_data %>%
  distinct(experiment_id, intervention, visualization) %>%
  count(intervention, visualization) %>%
  pivot_wider(names_from = visualization, values_from = n))

cat("\n======================================================================\n")
cat("MIXED MODEL ANOVA - HAMMING DISTANCE\n")
cat("======================================================================\n")

hamming_round_lmer <- lmer(
  hamming_distance ~ intervention * visualization * round + (1 | participant_id),
  data = roundwise_data
)

cat("\nANOVA Table:\n")
print(anova(hamming_round_lmer))

cat("\nEffect Sizes (Partial Eta Squared):\n")
print(eta_squared(hamming_round_lmer, partial = TRUE))

cat("\nPost-hoc Pairwise Comparisons for Intervention:\n")
emm_interv <- emmeans(hamming_round_lmer, ~ intervention)
print(emm_interv)
print(pairs(emm_interv, adjust = "tukey"))

cat("\n======================================================================\n")
cat("MIXED MODEL ANOVA - SUCCESS RATE\n")
cat("======================================================================\n")

sim_round_lmer <- lmer(
  simulation_success_rate ~ intervention * visualization * round + (1 | participant_id),
  data = roundwise_data
)

cat("\nANOVA Table:\n")
print(anova(sim_round_lmer))

cat("\nEffect Sizes (Partial Eta Squared):\n")
print(eta_squared(sim_round_lmer, partial = TRUE))

cat("\nPost-hoc Pairwise Comparisons for Intervention:\n")
emm_sr <- emmeans(sim_round_lmer, ~ intervention)
print(emm_sr)
print(pairs(emm_sr, adjust = "tukey"))

cat("\n======================================================================\n")
cat("MIXED MODEL ANOVA - Q-VALUE RMSE\n")
cat("======================================================================\n")

qrmse_round_lmer <- lmer(
  q_value_rmse ~ intervention * visualization * round + (1 | participant_id),
  data = roundwise_data
)

cat("\nANOVA Table:\n")
print(anova(qrmse_round_lmer))

cat("\nEffect Sizes (Partial Eta Squared):\n")
print(eta_squared(qrmse_round_lmer, partial = TRUE))

cat("\n======================================================================\n")
cat("COMPARISON WITH PAPER-REPORTED VALUES\n")
cat("======================================================================\n")
cat("
PAPER REPORTS (Hamming Distance):
- Interpretation type: F(3, 55.55) = 7.96, p < 0.001, η² = 0.30
- Round: F(2, 107.49) = 7.21, p = 0.001, η² = 0.12
- Visibility: F(1, 56.18) = 0.62, p = 0.44, η² = 0.01

Marginal means (Hamming):
- suggest: M = 0.20, 95% CI [0.08, 0.33]
- impede: M = 0.36, 95% CI [0.24, 0.47]
- reset: M = 0.57, 95% CI [0.45, 0.69]
- interrupt: M = 0.59, 95% CI [0.43, 0.76]

Post-hoc (Hamming):
- suggest vs interrupt: p = 0.002
- suggest vs reset: p < 0.001

PAPER REPORTS (Success Rate):
- Interpretation type: F(3, 56.79) = 8.54, p < 0.001, η² = 0.31
- Round: F(2, 109.45) = 7.60, p = 0.001, η² = 0.12
- Visibility: F(1, 57.65) = 0.09, p = 0.77, η² = 0.001

Marginal means (Success Rate):
- suggest: M = 0.63, 95% CI [0.48, 0.78]
- impede: M = 0.44, 95% CI [0.30, 0.58]
- interrupt: M = 0.31, 95% CI [0.11, 0.51]
- reset: M = 0.11, 95% CI [-0.04, 0.26]

Post-hoc (Success Rate):
- suggest vs reset: p < 0.001
- impede vs reset: p = 0.01

PAPER REPORTS (Q-RMSE):
- Interpretation type: F(3, 54.58) = 1.33, p = 0.27, η² = 0.07
- Visibility: F(1, 55.53) = 1.87, p = 0.18, η² = 0.03
- Round: F(2, 107.67) = 0.07, p = 0.93, η² = 0.001
")
