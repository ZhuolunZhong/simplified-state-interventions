"""
Reproduce the statistics reported in the CogSci paper.
"""

import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.formula.api import mixedlm
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# Load data
roundwise_eval = pd.read_csv('/home/jausterw/work/roomba/mentai2026/data/roundwise_evaluation_results.csv')

# Intervention types: 0=suggestion, 1=reset, 2=interrupt, 3=impede
# Visualization: 0=vis, 1=non_vis
intervention_labels = ["suggestion", "reset", "interrupt", "impede"]

def add_conditions(df):
    df = df.copy()
    df['intervention_idx'] = (df['experiment_id'] - 1) % 4
    df['intervention'] = df['intervention_idx'].apply(lambda x: intervention_labels[x])
    df['vis_idx'] = ((df['experiment_id'] - 1) // 4) % 2
    df['visualization'] = df['vis_idx'].apply(lambda x: 'vis' if x == 0 else 'non_vis')
    return df

roundwise_data = add_conditions(roundwise_eval)

print("=" * 70)
print("DATA OVERVIEW")
print("=" * 70)
print(f"\nTotal observations: {len(roundwise_data)}")
print(f"Unique participants: {roundwise_data['experiment_id'].nunique()}")
print("\nCondition counts:")
print(roundwise_data.groupby(['intervention', 'visualization'])['experiment_id'].nunique())

# Participant counts by condition
print("\n" + "=" * 70)
print("PARTICIPANT COUNTS BY CONDITION")
print("=" * 70)
participant_counts = roundwise_data.groupby(['intervention', 'visualization'])['experiment_id'].nunique().unstack()
print(participant_counts)
print(f"\nTotal participants: {roundwise_data['experiment_id'].nunique()}")

# Summary statistics by condition and round
print("\n" + "=" * 70)
print("HAMMING DISTANCE - DESCRIPTIVE STATISTICS BY CONDITION")
print("=" * 70)
summary = roundwise_data.groupby(['intervention', 'visualization', 'round'])['hamming_distance'].agg(['mean', 'std', 'count'])
print(summary.round(3))

# Marginal means by intervention type
print("\n" + "=" * 70)
print("MARGINAL MEANS BY INTERVENTION TYPE")
print("=" * 70)
marginal = roundwise_data.groupby('intervention')['hamming_distance'].agg(['mean', 'std', 'count'])
print(marginal.round(3))

print("\n" + "=" * 70)
print("MIXED MODEL ANOVA - HAMMING DISTANCE")
print("=" * 70)

# Prepare data for mixed model
roundwise_data['round_factor'] = roundwise_data['round'].astype(str)
roundwise_data['participant_id'] = roundwise_data['experiment_id'].astype(str)

# Fit mixed model with random intercepts by participant
# Using statsmodels mixedlm
model_hamming = mixedlm(
    "hamming_distance ~ C(intervention) * C(visualization) * C(round_factor)",
    roundwise_data,
    groups=roundwise_data['participant_id']
)
result_hamming = model_hamming.fit(reml=True)
print("\nMixed Model Summary (Hamming Distance):")
print(result_hamming.summary())

# For ANOVA-style F-tests, we need to use a different approach
# Let's use pingouin for mixed ANOVA
try:
    import pingouin as pg

    print("\n" + "=" * 70)
    print("MIXED ANOVA USING PINGOUIN - HAMMING DISTANCE")
    print("=" * 70)

    aov_hamming = pg.mixed_anova(
        data=roundwise_data,
        dv='hamming_distance',
        within='round',
        between=['intervention', 'visualization'],
        subject='experiment_id'
    )
    print(aov_hamming.round(4))

    print("\n" + "-" * 70)
    print("POST-HOC PAIRWISE COMPARISONS FOR INTERVENTION")
    print("-" * 70)
    posthoc = pg.pairwise_tests(
        data=roundwise_data,
        dv='hamming_distance',
        between='intervention',
        subject='experiment_id',
        padjust='tukey'
    )
    print(posthoc.round(4))

    # Marginal means with CIs
    print("\n" + "-" * 70)
    print("ESTIMATED MARGINAL MEANS BY INTERVENTION")
    print("-" * 70)
    for interv in ['suggestion', 'impede', 'reset', 'interrupt']:
        subset = roundwise_data[roundwise_data['intervention'] == interv]['hamming_distance']
        mean = subset.mean()
        se = subset.std() / np.sqrt(len(subset))
        ci_low = mean - 1.96 * se
        ci_high = mean + 1.96 * se
        print(f"{interv}: M = {mean:.2f}, 95% CI [{ci_low:.2f}, {ci_high:.2f}]")

    print("\n" + "=" * 70)
    print("MIXED ANOVA USING PINGOUIN - SUCCESS RATE")
    print("=" * 70)

    aov_success = pg.mixed_anova(
        data=roundwise_data,
        dv='simulation_success_rate',
        within='round',
        between=['intervention', 'visualization'],
        subject='experiment_id'
    )
    print(aov_success.round(4))

    print("\n" + "-" * 70)
    print("POST-HOC PAIRWISE COMPARISONS FOR INTERVENTION (SUCCESS RATE)")
    print("-" * 70)
    posthoc_sr = pg.pairwise_tests(
        data=roundwise_data,
        dv='simulation_success_rate',
        between='intervention',
        subject='experiment_id',
        padjust='tukey'
    )
    print(posthoc_sr.round(4))

    # Marginal means with CIs for success rate
    print("\n" + "-" * 70)
    print("ESTIMATED MARGINAL MEANS BY INTERVENTION (SUCCESS RATE)")
    print("-" * 70)
    for interv in ['suggestion', 'impede', 'reset', 'interrupt']:
        subset = roundwise_data[roundwise_data['intervention'] == interv]['simulation_success_rate']
        mean = subset.mean()
        se = subset.std() / np.sqrt(len(subset))
        ci_low = mean - 1.96 * se
        ci_high = mean + 1.96 * se
        print(f"{interv}: M = {mean:.2f}, 95% CI [{ci_low:.2f}, {ci_high:.2f}]")

    print("\n" + "=" * 70)
    print("MIXED ANOVA USING PINGOUIN - Q-RMSE")
    print("=" * 70)

    aov_qrmse = pg.mixed_anova(
        data=roundwise_data,
        dv='q_value_rmse',
        within='round',
        between=['intervention', 'visualization'],
        subject='experiment_id'
    )
    print(aov_qrmse.round(4))

except ImportError:
    print("\nNote: pingouin not installed. Install with: pip install pingouin")
    print("Using basic statsmodels approach instead.")

# Compare with paper values
print("\n" + "=" * 70)
print("COMPARISON WITH PAPER-REPORTED VALUES")
print("=" * 70)

print("""
PAPER REPORTS (Hamming Distance):
- Interpretation type: F(3, 55.55) = 7.96, p < 0.001, η² = 0.30
- Round: F(2, 107.49) = 7.21, p = 0.001, η² = 0.12
- Visibility: F(1, 56.18) = 0.62, p = 0.44, η² = 0.01

Marginal means (Hamming):
- suggest: M = 0.20, 95% CI [0.08, 0.33]
- impede: M = 0.36, 95% CI [0.24, 0.47]
- reset: M = 0.57, 95% CI [0.45, 0.69]
- interrupt: M = 0.59, 95% CI [0.43, 0.76]

PAPER REPORTS (Success Rate):
- Interpretation type: F(3, 56.79) = 8.54, p < 0.001, η² = 0.31
- Round: F(2, 109.45) = 7.60, p = 0.001, η² = 0.12
- Visibility: F(1, 57.65) = 0.09, p = 0.77, η² = 0.001

Marginal means (Success Rate):
- suggest: M = 0.63, 95% CI [0.48, 0.78]
- impede: M = 0.44, 95% CI [0.30, 0.58]
- interrupt: M = 0.31, 95% CI [0.11, 0.51]
- reset: M = 0.11, 95% CI [-0.04, 0.26]

PAPER REPORTS (Q-RMSE):
- Interpretation type: F(3, 54.58) = 1.33, p = 0.27, η² = 0.07
- Visibility: F(1, 55.53) = 1.87, p = 0.18, η² = 0.03
- Round: F(2, 107.67) = 0.07, p = 0.93, η² = 0.001
""")
